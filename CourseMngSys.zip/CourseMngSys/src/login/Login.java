package login;


import java.io.IOException;


import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import student.Studentdao;


public class Login extends HttpServlet 
{
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
	response.setContentType("text/html");
	 	PrintWriter out=response.getWriter();
	 	 String n=request.getParameter("username");
	 	 String p=request.getParameter("userpass");
	 	
	 	 Logindao d1=new Logindao();
	 	 
	 	 int i=d1.validate(n,p);
	 	 Studentdao d2= new Studentdao();
	 	 int j=d2.validate(n,p);
	 	 
	 	 if(i==1)
	 	 {
	 		 out.print("Login successfull\n");
	 		 RequestDispatcher rd=request.getRequestDispatcher("coursemng.html");
	 		rd.include(request,response);
	 		 
	 		 
	 	 }
	 	 else if(j==2)
	 	 {
	 		 out.print("Login successfull\n");
	 		 RequestDispatcher rd=request.getRequestDispatcher("File1.jsp");
	 		 rd.include(request,response);
	 	 }
	 	 
	 	 else
	 	 {
	 		 out.print("Invalid Details\n");
	 		 RequestDispatcher rd=request.getRequestDispatcher("first.html");
	 		 rd.include(request,response);
	 		 
	 	 }
	 	 out.close();
	 	 
	}
	

}

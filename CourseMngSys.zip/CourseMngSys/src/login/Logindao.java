package login;
  
import java.sql.*;

import java.lang.*;

import student.Query;

public class Logindao extends Query {

	public int validate(String username,String password)
	{
		boolean status=false;
		try
		{	
		Connection conn=implement();
		Query obj1=new Query();
		PreparedStatement ps;
	
			ps = conn.prepareStatement(
					"select * from admin where admin_name=? and admin_pass=?");
		
		ps.setString(1,username);
		ps.setString(2,password);
		
		ResultSet rs=ps.executeQuery();
		status=rs.next();
		if(status)
		{
			return 1;
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
			}
			return 0;	
	}
}

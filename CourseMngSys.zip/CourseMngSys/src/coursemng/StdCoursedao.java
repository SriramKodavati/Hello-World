package coursemng;
import student.Query;
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class StdCoursedao extends Query {
	
	public static void update(String subject,String time)
	{
		//System.out.println("stdcoursedao...class\n");
		try
		{	
		
		//System.out.println(subject);
		//System.out.println(time);
		String sql;
		if(time.equals("slot1"))
		{
		 sql="update course set nos1=s2.NEXTVAL where course_name=?";
		}
		else
		{
			 sql="update course set nos2=s2.NEXTVAL where course_name=?";
		}
		Connection conn=implement();
		PreparedStatement stmt = conn.prepareStatement(sql);
		//stmt.setInt(1,s2.NEXTVAL);
		stmt.setString(1,subject);
		//System.out.println("stdcoursedao...class2\n");
		
		int i=stmt.executeUpdate();
		//System.out.println(i);
		//System.out.println("stdcoursedao...class3 \n");
		
	}
		
		catch(Exception e)
		{
			System.out.println(e);
			
		}
	}

}

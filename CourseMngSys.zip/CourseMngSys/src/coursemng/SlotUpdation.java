package coursemng;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import student.Query;
public class SlotUpdation extends Query{
	
	public static void modify(String subject,String time) 
	{
		//System.out.println("stdcoursedao...class\n");
		try
		{	
	    Connection conn=implement();
		String sql;
		if(time.equals("slot1"))
		{
			sql="select nos1 from course where course_name=?";
			PreparedStatement stmt=conn.prepareStatement(sql);
			stmt.setString(1,subject);
			//int i=stmt.executeUpdate();
			//System.out.println(i);
			ResultSet r=stmt.executeQuery();
			int count = 0;
			while(r.next())
			//System.out.println(r.getInt(1));
				 count=r.getInt(1);
			//System.out.println(count);
			if(count<31)
			{
				count++;
				sql="update course set nos1=? where course_name=?";
				PreparedStatement st=conn.prepareStatement(sql);
				st.setInt(1,count);
				st.setString(2,subject);
				st.executeQuery();
			}
			else
				System.out.println("This Slot is full\n");
		}
		else if(time.equals("slot2"))
		{
			sql="select nos2 from course where course_name=?";
			PreparedStatement stmt=conn.prepareStatement(sql);
			stmt.setString(1,subject);
			ResultSet r=stmt.executeQuery();
			int count = 0;
			while(r.next())
				 count=r.getInt(1);
			//System.out.println(count);
			if(count<31)
			{
				count++;
				sql="update course set nos2=? where course_name=?";
				PreparedStatement st=conn.prepareStatement(sql);
				st.setInt(1,count);
				st.setString(2,subject);
				st.executeQuery();
			}
			else
				System.out.println("This Slot is full\n");
		}

}
		catch(Exception e)
		{
			System.out.println(e);
			
		}
	}
}
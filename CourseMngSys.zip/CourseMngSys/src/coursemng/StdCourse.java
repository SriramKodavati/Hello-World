package coursemng;

import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class StdCourse extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
String Course;

	Course=request.getParameter("subject");
	
String Slot=request.getParameter("slot");

//StdCoursedao.update(Course,Slot);
SlotUpdation.modify(Course,Slot);
RequestDispatcher rd=request.getRequestDispatcher("SignOut.html");
 rd.include(request,response);
	}

}

package coursemng;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Coursead extends HttpServlet {
      
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		//System.out.println("course");
	//var action=document.querySelector('input[name="rate"]:checked').value;
	//var update=document.getElementByName('group1');
		response.setContentType("text/html");
	 	PrintWriter out=response.getWriter();
	 	 String r=request.getParameter("coursename");
		String q2=request.getParameter("group1");
		//System.out.println(r);
		//System.out.println(q2);
		if("ADD".equals(q2))
		{
			Coursedao.add(r);
			 RequestDispatcher rd=request.getRequestDispatcher("SignOut.html");
	 		 rd.include(request,response);
			
		}
		else
		{
			Coursedao.delete(r);
			 RequestDispatcher rd=request.getRequestDispatcher("SignOut.html");
	 		 rd.include(request,response);
		}
		
		}
	
		
	}



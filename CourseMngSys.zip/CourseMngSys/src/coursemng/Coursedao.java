package coursemng;

import java.sql.Connection;
import student.Query;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class Coursedao extends Query{
	static Connection conn=implement();
	public static void add(String action)
	{
	//	System.out.println("add method");  
		try
		{
		// System.out.println("try...2 ");
		 
	String sql="insert into course (course_id,course_name) values (s1.NEXTVAL,?)";
		
		PreparedStatement stmt = conn.prepareStatement(sql);
	
	
	stmt.setString(1,action);
	//System.out.println("try...3 ");
	stmt.executeUpdate();
	//System.out.println("try...4");
		String oracle="select * from course";
		PreparedStatement stm=conn.prepareStatement(oracle);
	    
		ResultSet r=stm.executeQuery();
		}
catch(Exception e){
	System.out.println(e);
	
}
}
	public static void delete(String action)
	{
		
		
		try
		{	
		String sql="delete from course where course_name=?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setString(1,action);
		
		stmt.executeUpdate();
		String oracle="select * from course";
		PreparedStatement stm=conn.prepareStatement(oracle);
	    
		ResultSet r=stm.executeQuery();
		
		}
		
		catch(Exception e)
		{
			System.out.println(e);
			
		}
	}
}

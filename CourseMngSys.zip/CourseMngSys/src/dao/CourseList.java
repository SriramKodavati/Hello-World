package dao;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import student.Query;

public class CourseList extends Query
{
	public String[] list()
	{
	
		{
	try
	{	
		
			Connection conn=implement();
			int i=0;
			PreparedStatement ps1;
			
			ps1 = conn.prepareStatement(
					"select * from course");
			int k=0;
			ResultSet rs1=ps1.executeQuery();
			while(rs1.next())
			{
				++k;
			}
			System.out.println(k);
			String[] str =new String[k];
			PreparedStatement ps;
		
				ps = conn.prepareStatement(
						"select course_name from course");
			ResultSet rs=ps.executeQuery();
	   		//System.out.println(conn);
			//System.out.println("HAIII");
			while(rs.next())
			{
				str[i++]=rs.getString("course_name");
			}
			return (str);
	}
		catch(Exception e)
		{
			System.out.println(e);
			
		}
}
		return null;
}
	
}

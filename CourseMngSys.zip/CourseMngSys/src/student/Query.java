package student;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Query {
	
    public static Connection implement()
    {
	try
	{	
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection(
			"jdbc:oracle:thin:@localhost:1521:xe","system","system");
	return(con);

	}

	catch(Exception e)
	{
		System.out.println(e);
		
	}
	return null;

}

	public String sql;
}
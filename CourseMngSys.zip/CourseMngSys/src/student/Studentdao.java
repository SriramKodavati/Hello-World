package student;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Studentdao extends Query{
	public int validate(String username,String password)
	{
		//System.out.println("Studentdao class\n");
	boolean status=false;
	try
	{	
	//Class.forName("oracle.jdbc.driver.OracleDriver");
	//Connection con=DriverManager.getConnection(
		//	"jdbc:oracle:thin:@localhost:1521:xe","system","system");
	
	PreparedStatement ps;
      Connection conn=implement();
		ps = conn.prepareStatement(
				"select * from student where student_name=? and student_pass=?");
	
	ps.setString(1,username);
	ps.setString(2,password);
	System.out.println("hai..");
	ResultSet rs=ps.executeQuery();
	status=rs.next();
	if(status)
	{
		return 2;
	}
	}
	catch(Exception e)
	{
		System.out.println(e);
		}
		return 0;
		
	
	
}
}

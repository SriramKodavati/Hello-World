package student;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import login.Logindao;


public class Student extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
	//System.out.println("Student.java\n");
		response.setContentType("text/html");
	 	PrintWriter out=response.getWriter();
	 	 String n=request.getParameter("username");
	 	 String p=request.getParameter("userpass");
	 	
	 	 Studentdao d1=new Studentdao();
	 	// System.out.println("student.java servlet\n");
	 	 int i=d1.validate(n,p);
	 	 if(i>0)
	 	 {
	 		 out.print("Login successfull\n");
	 		 System.out.println("\n\n");
	 		 RequestDispatcher rd=request.getRequestDispatcher("File1.jsp");
	 		rd.include(request,response);
	 		 
	 		 
	 	 }
	 	 else
	 	 {
	 		 out.print("Invalid Details\n");
	 		 RequestDispatcher rd=request.getRequestDispatcher("student.html");
	 		 rd.include(request,response);
	 		 
	 	 }
	 	 out.close();
	 	 
	}
	
	}


